import { useState } from 'react';
import { User, SkillRequest } from '../types';
import { users as initialUsers, skillRequests as initialRequests, currentUser } from '../data/mockData';

export const useSkillSwap = () => {
  const [users, setUsers] = useState<User[]>(initialUsers);
  const [requests, setRequests] = useState<SkillRequest[]>(initialRequests);
  const [searchTerm, setSearchTerm] = useState('');
  const [skillFilter, setSkillFilter] = useState('');

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.bio.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesSkill = !skillFilter || 
                        user.skillsOffered.some(skill => 
                          skill.toLowerCase().includes(skillFilter.toLowerCase())
                        );
    
    return matchesSearch && matchesSkill;
  });

  const sendRequest = (toUserId: string, skillOffered: string, skillWanted: string, message: string) => {
    const newRequest: SkillRequest = {
      id: Date.now().toString(),
      fromUserId: currentUser.id,
      toUserId,
      skillOffered,
      skillWanted,
      message,
      status: 'pending',
      createdAt: new Date()
    };
    
    setRequests(prev => [...prev, newRequest]);
  };

  const updateRequestStatus = (requestId: string, status: SkillRequest['status']) => {
    setRequests(prev => 
      prev.map(req => 
        req.id === requestId ? { ...req, status } : req
      )
    );
  };

  const getUserById = (id: string) => {
    if (id === currentUser.id) return currentUser;
    return users.find(user => user.id === id);
  };

  const getMyRequests = () => {
    return requests.filter(req => req.fromUserId === currentUser.id);
  };

  const getIncomingRequests = () => {
    return requests.filter(req => req.toUserId === currentUser.id);
  };

  return {
    users: filteredUsers,
    requests,
    searchTerm,
    setSearchTerm,
    skillFilter,
    setSkillFilter,
    sendRequest,
    updateRequestStatus,
    getUserById,
    getMyRequests,
    getIncomingRequests,
    currentUser
  };
};