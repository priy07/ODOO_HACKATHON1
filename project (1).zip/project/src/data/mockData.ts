import { User, SkillRequest } from '../types';

export const currentUser: User = {
  id: '1',
  name: 'Alex Thompson',
  avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop',
  location: 'San Francisco, CA',
  bio: 'Passionate about design and always eager to learn new skills. Love connecting with creative people!',
  skillsOffered: ['Photoshop', 'UI/UX Design', 'Figma', 'Graphic Design'],
  skillsWanted: ['Yoga', 'Guitar', 'Spanish', 'Cooking'],
  rating: 4.8,
  totalSwaps: 23
};

export const users: User[] = [
  {
    id: '2',
    name: 'Sarah Chen',
    avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop',
    location: 'New York, NY',
    bio: 'Yoga instructor and wellness coach. Love helping others find balance through movement and mindfulness.',
    skillsOffered: ['Yoga', 'Meditation', 'Nutrition', 'Pilates'],
    skillsWanted: ['Web Design', 'Photography', 'Marketing', 'Photoshop'],
    rating: 4.9,
    totalSwaps: 31
  },
  {
    id: '3',
    name: 'Marcus Rodriguez',
    avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop',
    location: 'Austin, TX',
    bio: 'Professional chef with 10 years experience. Love sharing the art of cooking with others!',
    skillsOffered: ['Cooking', 'Baking', 'Food Photography', 'Recipe Development'],
    skillsWanted: ['Guitar', 'Video Editing', 'Spanish', 'Business Strategy'],
    rating: 4.7,
    totalSwaps: 18
  },
  {
    id: '4',
    name: 'Emily Johnson',
    avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop',
    location: 'Seattle, WA',
    bio: 'Full-stack developer and tech enthusiast. Always excited to share knowledge and learn new creative skills.',
    skillsOffered: ['Web Development', 'React', 'Node.js', 'Database Design'],
    skillsWanted: ['Pottery', 'Painting', 'Photography', 'Interior Design'],
    rating: 4.9,
    totalSwaps: 27
  },
  {
    id: '5',
    name: 'David Kim',
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop',
    location: 'Los Angeles, CA',
    bio: 'Professional musician and guitar teacher. Music is my passion and I love sharing it with others.',
    skillsOffered: ['Guitar', 'Music Theory', 'Songwriting', 'Audio Production'],
    skillsWanted: ['Video Editing', 'Graphic Design', 'Marketing', 'French'],
    rating: 4.8,
    totalSwaps: 22
  },
  {
    id: '6',
    name: 'Lisa Wang',
    avatar: 'https://images.pexels.com/photos/1130626/pexels-photo-1130626.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop',
    location: 'Boston, MA',
    bio: 'Language enthusiast and world traveler. Fluent in 5 languages and love helping others communicate.',
    skillsOffered: ['Spanish', 'French', 'Mandarin', 'Language Tutoring'],
    skillsWanted: ['Photography', 'Hiking', 'Cooking', 'Yoga'],
    rating: 4.9,
    totalSwaps: 35
  }
];

export const skillRequests: SkillRequest[] = [
  {
    id: '1',
    fromUserId: '2',
    toUserId: '1',
    skillOffered: 'Yoga',
    skillWanted: 'Photoshop',
    message: 'Hi Alex! I noticed you offer Photoshop skills and I need help with some basic photo editing. I can teach you yoga in return - would love to do a skill swap!',
    status: 'pending',
    createdAt: new Date('2024-01-15')
  },
  {
    id: '2',
    fromUserId: '1',
    toUserId: '3',
    skillOffered: 'UI/UX Design',
    skillWanted: 'Cooking',
    message: 'Hey Marcus! I\'d love to learn some cooking techniques from you. I can help you with UI/UX design for any projects you might have.',
    status: 'accepted',
    createdAt: new Date('2024-01-14')
  },
  {
    id: '3',
    fromUserId: '5',
    toUserId: '1',
    skillOffered: 'Guitar',
    skillWanted: 'Graphic Design',
    message: 'Hi! I see you\'re skilled in graphic design. I could teach you guitar basics in exchange for some design help with my band\'s promotional materials.',
    status: 'pending',
    createdAt: new Date('2024-01-13')
  }
];