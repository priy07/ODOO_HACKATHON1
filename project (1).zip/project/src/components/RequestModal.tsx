import React, { useState } from 'react';
import { User } from '../types';
import { X, Send } from 'lucide-react';

interface RequestModalProps {
  targetUser: User;
  currentUserSkills: string[];
  onClose: () => void;
  onSend: (toUserId: string, skillOffered: string, skillWanted: string, message: string) => void;
}

export const RequestModal: React.FC<RequestModalProps> = ({
  targetUser,
  currentUserSkills,
  onClose,
  onSend
}) => {
  const [skillOffered, setSkillOffered] = useState('');
  const [skillWanted, setSkillWanted] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (skillOffered && skillWanted && message.trim()) {
      onSend(targetUser.id, skillOffered, skillWanted, message);
      onClose();
    }
  };

  // Find matching skills
  const matchingSkills = currentUserSkills.filter(skill =>
    targetUser.skillsWanted.some(wanted =>
      wanted.toLowerCase().includes(skill.toLowerCase())
    )
  );

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-2xl max-w-md w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900">
              Send Skill Request to {targetUser.name}
            </h2>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors"
            >
              <X size={24} />
            </button>
          </div>

          {matchingSkills.length > 0 && (
            <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded-lg">
              <p className="text-sm text-green-800 font-medium mb-1">Perfect Match!</p>
              <p className="text-sm text-green-700">
                You offer skills they want: {matchingSkills.join(', ')}
              </p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Skill You're Offering
              </label>
              <select
                value={skillOffered}
                onChange={(e) => setSkillOffered(e.target.value)}
                className="w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              >
                <option value="">Select a skill you offer</option>
                {currentUserSkills.map((skill, index) => (
                  <option key={index} value={skill}>{skill}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Skill You Want to Learn
              </label>
              <select
                value={skillWanted}
                onChange={(e) => setSkillWanted(e.target.value)}
                className="w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              >
                <option value="">Select a skill they offer</option>
                {targetUser.skillsOffered.map((skill, index) => (
                  <option key={index} value={skill}>{skill}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Message
              </label>
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Tell them why you'd like to do a skill swap..."
                className="w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent h-24 resize-none"
                required
              />
            </div>

            <div className="flex space-x-3 pt-4">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 px-4 py-2.5 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600 text-white py-2.5 px-4 rounded-lg font-medium hover:from-blue-700 hover:to-purple-700 transition-all duration-200 flex items-center justify-center space-x-2"
              >
                <Send size={18} />
                <span>Send Request</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};