import React, { useState } from 'react';
import { SkillRequest } from '../types';
import { SkillBadge } from './SkillBadge';
import { Check, X, Clock, CheckCircle, MessageCircle, Calendar } from 'lucide-react';

interface RequestsManagerProps {
  incomingRequests: SkillRequest[];
  outgoingRequests: SkillRequest[];
  onUpdateStatus: (requestId: string, status: SkillRequest['status']) => void;
  getUserById: (id: string) => any;
}

export const RequestsManager: React.FC<RequestsManagerProps> = ({
  incomingRequests,
  outgoingRequests,
  onUpdateStatus,
  getUserById
}) => {
  const [activeTab, setActiveTab] = useState<'incoming' | 'outgoing'>('incoming');

  const getStatusIcon = (status: SkillRequest['status']) => {
    switch (status) {
      case 'pending':
        return <Clock className="text-yellow-500" size={16} />;
      case 'accepted':
        return <CheckCircle className="text-green-500" size={16} />;
      case 'declined':
        return <X className="text-red-500" size={16} />;
      case 'completed':
        return <Check className="text-blue-500" size={16} />;
      default:
        return <Clock className="text-gray-500" size={16} />;
    }
  };

  const getStatusColor = (status: SkillRequest['status']) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'accepted':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'declined':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'completed':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const RequestCard: React.FC<{ request: SkillRequest; type: 'incoming' | 'outgoing' }> = ({ 
    request, 
    type 
  }) => {
    const otherUserId = type === 'incoming' ? request.fromUserId : request.toUserId;
    const otherUser = getUserById(otherUserId);
    
    if (!otherUser) return null;

    return (
      <div className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-md transition-shadow">
        <div className="flex items-start space-x-4">
          <img
            src={otherUser.avatar}
            alt={otherUser.name}
            className="w-12 h-12 rounded-full object-cover border-2 border-gray-100"
          />
          
          <div className="flex-1">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-semibold text-gray-900">{otherUser.name}</h3>
              <div className={`flex items-center space-x-1 px-2.5 py-1 rounded-full text-xs font-medium border ${getStatusColor(request.status)}`}>
                {getStatusIcon(request.status)}
                <span className="capitalize">{request.status}</span>
              </div>
            </div>
            
            <div className="flex items-center space-x-2 mb-3 text-sm text-gray-600">
              <Calendar size={14} />
              <span>{request.createdAt.toLocaleDateString()}</span>
            </div>

            <div className="flex items-center space-x-4 mb-3">
              <div className="flex items-center space-x-2">
                <span className="text-sm text-gray-600">
                  {type === 'incoming' ? 'They offer:' : 'You offered:'}
                </span>
                <SkillBadge skill={request.skillOffered} type="offered" size="sm" />
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-sm text-gray-600">
                  {type === 'incoming' ? 'They want:' : 'You want:'}
                </span>
                <SkillBadge skill={request.skillWanted} type="wanted" size="sm" />
              </div>
            </div>

            <div className="bg-gray-50 rounded-lg p-3 mb-4">
              <div className="flex items-start space-x-2">
                <MessageCircle size={14} className="text-gray-500 mt-0.5 flex-shrink-0" />
                <p className="text-sm text-gray-700 leading-relaxed">{request.message}</p>
              </div>
            </div>

            {type === 'incoming' && request.status === 'pending' && (
              <div className="flex space-x-2">
                <button
                  onClick={() => onUpdateStatus(request.id, 'accepted')}
                  className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors font-medium flex items-center justify-center space-x-2"
                >
                  <Check size={16} />
                  <span>Accept</span>
                </button>
                <button
                  onClick={() => onUpdateStatus(request.id, 'declined')}
                  className="flex-1 bg-gray-600 text-white py-2 px-4 rounded-lg hover:bg-gray-700 transition-colors font-medium flex items-center justify-center space-x-2"
                >
                  <X size={16} />
                  <span>Decline</span>
                </button>
              </div>
            )}

            {request.status === 'accepted' && (
              <button
                onClick={() => onUpdateStatus(request.id, 'completed')}
                className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors font-medium flex items-center justify-center space-x-2"
              >
                <Check size={16} />
                <span>Mark as Completed</span>
              </button>
            )}
          </div>
        </div>
      </div>
    );
  };

  const currentRequests = activeTab === 'incoming' ? incomingRequests : outgoingRequests;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Skill Exchange Requests</h2>
        
        <div className="flex bg-gray-100 rounded-lg p-1">
          <button
            onClick={() => setActiveTab('incoming')}
            className={`px-4 py-2 rounded-md font-medium transition-all ${
              activeTab === 'incoming'
                ? 'bg-white text-blue-600 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            Incoming ({incomingRequests.length})
          </button>
          <button
            onClick={() => setActiveTab('outgoing')}
            className={`px-4 py-2 rounded-md font-medium transition-all ${
              activeTab === 'outgoing'
                ? 'bg-white text-blue-600 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            Sent ({outgoingRequests.length})
          </button>
        </div>
      </div>

      {currentRequests.length === 0 ? (
        <div className="text-center py-12 bg-gray-50 rounded-lg">
          <MessageCircle className="mx-auto text-gray-400 mb-4" size={48} />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            No {activeTab} requests
          </h3>
          <p className="text-gray-600">
            {activeTab === 'incoming' 
              ? "You haven't received any skill swap requests yet." 
              : "You haven't sent any skill swap requests yet."
            }
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {currentRequests.map(request => (
            <RequestCard 
              key={request.id} 
              request={request} 
              type={activeTab}
            />
          ))}
        </div>
      )}
    </div>
  );
};