import React from 'react';

interface SkillBadgeProps {
  skill: string;
  type: 'offered' | 'wanted';
  size?: 'sm' | 'md';
  onClick?: () => void;
}

export const SkillBadge: React.FC<SkillBadgeProps> = ({ 
  skill, 
  type, 
  size = 'md',
  onClick 
}) => {
  const baseClasses = `inline-flex items-center font-medium rounded-full transition-all duration-200 ${
    onClick ? 'cursor-pointer hover:scale-105' : ''
  }`;
  
  const sizeClasses = size === 'sm' 
    ? 'px-2.5 py-1 text-xs' 
    : 'px-3 py-1.5 text-sm';
  
  const typeClasses = type === 'offered'
    ? 'bg-green-100 text-green-800 border border-green-200 hover:bg-green-200'
    : 'bg-blue-100 text-blue-800 border border-blue-200 hover:bg-blue-200';

  return (
    <span 
      className={`${baseClasses} ${sizeClasses} ${typeClasses}`}
      onClick={onClick}
    >
      {skill}
    </span>
  );
};