import React, { useState } from 'react';
import { User } from '../types';
import { SkillBadge } from './SkillBadge';
import { Star, MapPin, Award, MessageCircle } from 'lucide-react';
import { RequestModal } from './RequestModal';

interface UserCardProps {
  user: User;
  onSendRequest: (toUserId: string, skillOffered: string, skillWanted: string, message: string) => void;
  currentUserSkills: string[];
}

export const UserCard: React.FC<UserCardProps> = ({ user, onSendRequest, currentUserSkills }) => {
  const [showRequestModal, setShowRequestModal] = useState(false);

  return (
    <>
      <div className="bg-white rounded-xl shadow-md hover:shadow-lg transition-all duration-300 overflow-hidden border border-gray-100">
        <div className="p-6">
          <div className="flex items-start space-x-4 mb-4">
            <img
              src={user.avatar}
              alt={user.name}
              className="w-16 h-16 rounded-full object-cover border-2 border-gray-100"
            />
            <div className="flex-1">
              <h3 className="text-xl font-semibold text-gray-900 mb-1">{user.name}</h3>
              <div className="flex items-center text-gray-600 text-sm mb-2">
                <MapPin size={14} className="mr-1" />
                {user.location}
              </div>
              <div className="flex items-center space-x-4 text-sm text-gray-600">
                <div className="flex items-center">
                  <Star size={14} className="text-yellow-400 mr-1" />
                  <span className="font-medium">{user.rating}</span>
                </div>
                <div className="flex items-center">
                  <Award size={14} className="text-blue-500 mr-1" />
                  <span>{user.totalSwaps} swaps</span>
                </div>
              </div>
            </div>
          </div>

          <p className="text-gray-700 text-sm mb-4 leading-relaxed">{user.bio}</p>

          <div className="space-y-3 mb-4">
            <div>
              <h4 className="text-sm font-semibold text-gray-900 mb-2">Skills Offered</h4>
              <div className="flex flex-wrap gap-1.5">
                {user.skillsOffered.map((skill, index) => (
                  <SkillBadge key={index} skill={skill} type="offered" size="sm" />
                ))}
              </div>
            </div>

            <div>
              <h4 className="text-sm font-semibold text-gray-900 mb-2">Skills Wanted</h4>
              <div className="flex flex-wrap gap-1.5">
                {user.skillsWanted.map((skill, index) => (
                  <SkillBadge key={index} skill={skill} type="wanted" size="sm" />
                ))}
              </div>
            </div>
          </div>

          <button
            onClick={() => setShowRequestModal(true)}
            className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-2.5 px-4 rounded-lg font-medium hover:from-blue-700 hover:to-purple-700 transition-all duration-200 flex items-center justify-center space-x-2 shadow-sm hover:shadow-md"
          >
            <MessageCircle size={18} />
            <span>Send Skill Request</span>
          </button>
        </div>
      </div>

      {showRequestModal && (
        <RequestModal
          targetUser={user}
          currentUserSkills={currentUserSkills}
          onClose={() => setShowRequestModal(false)}
          onSend={onSendRequest}
        />
      )}
    </>
  );
};