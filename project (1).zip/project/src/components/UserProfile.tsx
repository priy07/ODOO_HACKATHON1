import React, { useState } from 'react';
import { User } from '../types';
import { SkillBadge } from './SkillBadge';
import { Star, MapPin, Award, Plus, X, Edit3 } from 'lucide-react';

interface UserProfileProps {
  user: User;
  onUpdateProfile?: (updates: Partial<User>) => void;
}

export const UserProfile: React.FC<UserProfileProps> = ({ user, onUpdateProfile }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editedUser, setEditedUser] = useState(user);
  const [newSkillOffered, setNewSkillOffered] = useState('');
  const [newSkillWanted, setNewSkillWanted] = useState('');

  const handleSave = () => {
    if (onUpdateProfile) {
      onUpdateProfile(editedUser);
    }
    setIsEditing(false);
  };

  const addSkill = (type: 'offered' | 'wanted') => {
    const skill = type === 'offered' ? newSkillOffered : newSkillWanted;
    if (!skill.trim()) return;

    const skillArray = type === 'offered' ? 'skillsOffered' : 'skillsWanted';
    setEditedUser(prev => ({
      ...prev,
      [skillArray]: [...prev[skillArray], skill.trim()]
    }));

    if (type === 'offered') {
      setNewSkillOffered('');
    } else {
      setNewSkillWanted('');
    }
  };

  const removeSkill = (type: 'offered' | 'wanted', index: number) => {
    const skillArray = type === 'offered' ? 'skillsOffered' : 'skillsWanted';
    setEditedUser(prev => ({
      ...prev,
      [skillArray]: prev[skillArray].filter((_, i) => i !== index)
    }));
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-xl shadow-lg overflow-hidden">
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-8 text-white">
          <div className="flex items-start justify-between">
            <div className="flex items-center space-x-6">
              <img
                src={user.avatar}
                alt={user.name}
                className="w-24 h-24 rounded-full border-4 border-white/20 object-cover"
              />
              <div>
                <h1 className="text-3xl font-bold mb-2">{user.name}</h1>
                <div className="flex items-center text-blue-100 mb-2">
                  <MapPin size={18} className="mr-2" />
                  {user.location}
                </div>
                <div className="flex items-center space-x-6 text-sm">
                  <div className="flex items-center">
                    <Star size={16} className="text-yellow-300 mr-1" />
                    <span className="font-medium">{user.rating} rating</span>
                  </div>
                  <div className="flex items-center">
                    <Award size={16} className="text-blue-200 mr-1" />
                    <span>{user.totalSwaps} successful swaps</span>
                  </div>
                </div>
              </div>
            </div>
            
            {onUpdateProfile && (
              <button
                onClick={() => setIsEditing(!isEditing)}
                className="bg-white/20 hover:bg-white/30 text-white px-4 py-2 rounded-lg transition-colors flex items-center space-x-2"
              >
                <Edit3 size={18} />
                <span>{isEditing ? 'Cancel' : 'Edit Profile'}</span>
              </button>
            )}
          </div>
        </div>

        <div className="p-8">
          <div className="space-y-8">
            <div>
              <h2 className="text-xl font-semibold text-gray-900 mb-3">About</h2>
              {isEditing ? (
                <textarea
                  value={editedUser.bio}
                  onChange={(e) => setEditedUser(prev => ({ ...prev, bio: e.target.value }))}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent h-24 resize-none"
                  placeholder="Tell others about yourself..."
                />
              ) : (
                <p className="text-gray-700 leading-relaxed">{user.bio}</p>
              )}
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-semibold text-gray-900">Skills I Offer</h2>
                  {isEditing && (
                    <span className="text-sm text-gray-500">
                      {editedUser.skillsOffered.length} skills
                    </span>
                  )}
                </div>
                
                <div className="space-y-3">
                  <div className="flex flex-wrap gap-2">
                    {(isEditing ? editedUser.skillsOffered : user.skillsOffered).map((skill, index) => (
                      <div key={index} className="relative group">
                        <SkillBadge skill={skill} type="offered" />
                        {isEditing && (
                          <button
                            onClick={() => removeSkill('offered', index)}
                            className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full p-0.5 opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <X size={12} />
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                  
                  {isEditing && (
                    <div className="flex space-x-2">
                      <input
                        type="text"
                        value={newSkillOffered}
                        onChange={(e) => setNewSkillOffered(e.target.value)}
                        placeholder="Add a skill you offer..."
                        className="flex-1 p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        onKeyPress={(e) => e.key === 'Enter' && addSkill('offered')}
                      />
                      <button
                        onClick={() => addSkill('offered')}
                        className="bg-green-600 text-white px-3 py-2 rounded-lg hover:bg-green-700 transition-colors"
                      >
                        <Plus size={16} />
                      </button>
                    </div>
                  )}
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-semibold text-gray-900">Skills I Want to Learn</h2>
                  {isEditing && (
                    <span className="text-sm text-gray-500">
                      {editedUser.skillsWanted.length} skills
                    </span>
                  )}
                </div>
                
                <div className="space-y-3">
                  <div className="flex flex-wrap gap-2">
                    {(isEditing ? editedUser.skillsWanted : user.skillsWanted).map((skill, index) => (
                      <div key={index} className="relative group">
                        <SkillBadge skill={skill} type="wanted" />
                        {isEditing && (
                          <button
                            onClick={() => removeSkill('wanted', index)}
                            className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full p-0.5 opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <X size={12} />
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                  
                  {isEditing && (
                    <div className="flex space-x-2">
                      <input
                        type="text"
                        value={newSkillWanted}
                        onChange={(e) => setNewSkillWanted(e.target.value)}
                        placeholder="Add a skill you want to learn..."
                        className="flex-1 p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        onKeyPress={(e) => e.key === 'Enter' && addSkill('wanted')}
                      />
                      <button
                        onClick={() => addSkill('wanted')}
                        className="bg-blue-600 text-white px-3 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                      >
                        <Plus size={16} />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {isEditing && (
              <div className="flex justify-end space-x-3 pt-4 border-t border-gray-200">
                <button
                  onClick={() => {
                    setIsEditing(false);
                    setEditedUser(user);
                  }}
                  className="px-6 py-2.5 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSave}
                  className="px-6 py-2.5 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all duration-200 font-medium"
                >
                  Save Changes
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};