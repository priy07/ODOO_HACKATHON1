import React, { useState } from 'react';
import { UserCard } from './UserCard';
import { SkillBadge } from './SkillBadge';
import { User } from '../types';
import { Filter, Users } from 'lucide-react';

interface BrowseSkillsProps {
  users: User[];
  onSendRequest: (toUserId: string, skillOffered: string, skillWanted: string, message: string) => void;
  currentUserSkills: string[];
  skillFilter: string;
  onSkillFilterChange: (skill: string) => void;
}

export const BrowseSkills: React.FC<BrowseSkillsProps> = ({
  users,
  onSendRequest,
  currentUserSkills,
  skillFilter,
  onSkillFilterChange
}) => {
  const [showFilters, setShowFilters] = useState(false);

  // Get all unique skills from all users
  const allSkills = Array.from(
    new Set([
      ...users.flatMap(user => user.skillsOffered),
      ...users.flatMap(user => user.skillsWanted)
    ])
  ).sort();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Users className="text-blue-600" size={24} />
          <h2 className="text-2xl font-bold text-gray-900">
            Discover Skills ({users.length} {users.length === 1 ? 'person' : 'people'})
          </h2>
        </div>
        
        <button
          onClick={() => setShowFilters(!showFilters)}
          className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
        >
          <Filter size={18} />
          <span>Filters</span>
        </button>
      </div>

      {showFilters && (
        <div className="bg-gray-50 rounded-lg p-4 space-y-3">
          <h3 className="font-semibold text-gray-900">Filter by Skills</h3>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => onSkillFilterChange('')}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                !skillFilter
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
              }`}
            >
              All Skills
            </button>
            {allSkills.slice(0, 15).map((skill, index) => (
              <button
                key={index}
                onClick={() => onSkillFilterChange(skill)}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                  skillFilter === skill
                    ? 'bg-blue-600 text-white'
                    : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
                }`}
              >
                {skill}
              </button>
            ))}
          </div>
        </div>
      )}

      {users.length === 0 ? (
        <div className="text-center py-12">
          <Users className="mx-auto text-gray-400 mb-4" size={48} />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No users found</h3>
          <p className="text-gray-600">Try adjusting your search or filters to find more people.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {users.map(user => (
            <UserCard
              key={user.id}
              user={user}
              onSendRequest={onSendRequest}
              currentUserSkills={currentUserSkills}
            />
          ))}
        </div>
      )}
    </div>
  );
};