export interface User {
  id: string;
  name: string;
  avatar: string;
  location: string;
  bio: string;
  skillsOffered: string[];
  skillsWanted: string[];
  rating: number;
  totalSwaps: number;
}

export interface SkillRequest {
  id: string;
  fromUserId: string;
  toUserId: string;
  skillOffered: string;
  skillWanted: string;
  message: string;
  status: 'pending' | 'accepted' | 'declined' | 'completed';
  createdAt: Date;
}

export interface UserProfile {
  user: User;
  isCurrentUser: boolean;
}