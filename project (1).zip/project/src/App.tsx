import React, { useState } from 'react';
import { Header } from './components/Header';
import { BrowseSkills } from './components/BrowseSkills';
import { UserProfile } from './components/UserProfile';
import { RequestsManager } from './components/RequestsManager';
import { useSkillSwap } from './hooks/useSkillSwap';

function App() {
  const [activeTab, setActiveTab] = useState('browse');
  const {
    users,
    searchTerm,
    setSearchTerm,
    skillFilter,
    setSkillFilter,
    sendRequest,
    updateRequestStatus,
    getUserById,
    getMyRequests,
    getIncomingRequests,
    currentUser
  } = useSkillSwap();

  const renderContent = () => {
    switch (activeTab) {
      case 'browse':
        return (
          <BrowseSkills
            users={users}
            onSendRequest={sendRequest}
            currentUserSkills={currentUser.skillsOffered}
            skillFilter={skillFilter}
            onSkillFilterChange={setSkillFilter}
          />
        );
      case 'profile':
        return (
          <UserProfile
            user={currentUser}
            onUpdateProfile={(updates) => {
              // In a real app, this would update the user in the backend
              console.log('Profile updated:', updates);
            }}
          />
        );
      case 'requests':
        return (
          <RequestsManager
            incomingRequests={getIncomingRequests()}
            outgoingRequests={getMyRequests()}
            onUpdateStatus={updateRequestStatus}
            getUserById={getUserById}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header
        activeTab={activeTab}
        onTabChange={setActiveTab}
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
      />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderContent()}
      </main>
    </div>
  );
}

export default App;
